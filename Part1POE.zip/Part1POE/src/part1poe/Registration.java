/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package part1poe;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author AndiswaBuhle
 */
public class Registration {
    private static final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$";
    private static final Pattern pattern = Pattern.compile(PASSWORD_PATTERN);

    public static void main(String[] args) {
      
        // User registration
          try(Scanner scanner = new Scanner(System.in)) {
            // User registration
            System.out.println("Welcome to the registration system!");
            System.out.print("Enter your username: ");
            String username = scanner.nextLine();
            
            String password;
            Matcher matcher;
            do {
                System.out.print("Enter your password (must contain at least one digit, one lowercase letter, one uppercase letter, one special character, and be at least 8 characters long): ");
                password = scanner.nextLine();
                matcher = pattern.matcher(password);
            } while (!matcher.matches());
            
            System.out.println("Registration successful!");
            
            // User login
            System.out.println("Welcome to the login system!");
            System.out.print("Enter your username: ");
            String enteredUsername = scanner.nextLine();
            
            System.out.print("Enter your password: ");
            String enteredPassword = scanner.nextLine();
            
            if (enteredUsername.equals(username) && enteredPassword.equals(password)) {
                System.out.println("Login successful!");
            } else {
                System.out.println("Incorrect username or password.");
            }
        }
    }
}

