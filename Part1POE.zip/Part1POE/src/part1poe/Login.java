/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package part1poe;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author AndiswaBuhle
 */
public class Login {
    
    private static final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$";
    private static final Pattern pattern = Pattern.compile(PASSWORD_PATTERN);

    public static void main(String[] args) {
        // User login
        try (Scanner scanner = new Scanner(System.in)) {
            // User login
            System.out.println("Welcome to the login system!");
            System.out.print("Enter your username: ");
            String enteredUsername = scanner.nextLine();
            
            String enteredPassword;
            Matcher matcher;
            do {
                System.out.print("Enter your password (must contain at least one digit, one lowercase letter, one uppercase letter, one special character, and be at least 8 characters long): ");
                enteredPassword = scanner.nextLine();
                matcher = pattern.matcher(enteredPassword);
            } while (!matcher.matches());
            
            // Check if username and password match
            boolean isUsernameCorrect = checkUsername(enteredUsername);
            boolean isPasswordCorrect = checkPassword(enteredPassword);
            
            if (isUsernameCorrect && isPasswordCorrect) {
                System.out.println("Login successful!");
            } else {
                System.out.println("Incorrect username or password.");
            }
        }
    }

    private static boolean checkUsername(String enteredUsername) {
        // Check if username is correct 
        String registeredUsername = "username";
        return enteredUsername.equals(registeredUsername);
    }

    private static boolean checkPassword(String enteredPassword) {
        // Check if password is correct 
        String registeredPassword = "Password1@";
        return enteredPassword.equals(registeredPassword);
    }
}

    

