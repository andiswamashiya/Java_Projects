/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question2;

import java.text.DecimalFormat;

/**
 *
 * @author AndiswaBuhle
 */
public class Question2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       //array 
        int Hospital [][] = {{800000, 1500000, 2000000},
                           {700000, 1200000, 1600000},
                           {750000, 1300000, 1800000}};
        
        String province;
        province= "Guateng";
        province = "Natal";
        province = "Cape Town";
       
        //code here
    System.out.println("\tProvince");  
     System.out.print("\t\tFLAT");
     System.out.print("\t\tTOWNHOUSE");
     System.out.print("\t\tHOUSE");
     System.out.println("\n-------------------------------------------------------------------------------------");
     
     double sum = 0;
     for(int i = 0; i < Hospital.length; i++) {
         sum += Hospital[0][i];
     }
     
     double sum0 = 0;
     for(int i = 0; i < Hospital.length; i++) {
        sum0+= Hospital[1][i];
     }
     
     double sum1 = 0;
     for(int i = 0; i < Hospital.length; i++) {
         sum1+= Hospital[2][i];
     }
     
       //converting the average into decimal places
       DecimalFormat  format = new DecimalFormat("0,000");
     
     for(int i = 0; i < Hospital.length; i++) {
         switch(i) {
             case 0 : System.out.print("\nGauteng");
             break;
             case 1 : System.out.print("\nNatal");
             break;
             case 2 : System.out.print("\nCape");
             break;
         }
         for(int j = 0; j < Hospital[i].length; j++) {
             System.out.print("\t" + "\t" + "R " + Hospital[i][j] );
         }
     }
     
     //printimg the avarage
     int i = 0;
     System.out.println();
     System.out.println("\nAverage property prices in Gauteng = " + "R " + format.format(sum/Hospital[i].length));
     System.out.println("Average property prices in Natal= " + "R " + format.format(sum0/Hospital[i].length) );
     System.out.println("Average property prices in Cape = " + "R " + format.format(sum1/Hospital[i].length));
     
    }
    
}
