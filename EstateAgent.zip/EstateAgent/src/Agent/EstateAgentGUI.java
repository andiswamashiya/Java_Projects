/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Agent;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author AndiswaBuhle
 */
public class EstateAgentGUI extends javax.swing.JFrame {
     private JComboBox<String> locationComboBox;
    private JTextField agentNameField;
    private JTextField propertyPriceField;
    private JTextField commissionPercentageField;
    private JTextArea reportTextArea;

    private EstateAgent estateAgent;

    public EstateAgentGUI() {
        estateAgent = new EstateAgent();

        setTitle("Estate Agent Commission Calculator");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        createUI();

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void createUI() {
        locationComboBox = new JComboBox<>(new String[]{"Cape Town", "Durban", "Pretoria"});
        agentNameField = new JTextField(15);
        propertyPriceField = new JTextField(15);
        commissionPercentageField = new JTextField(15);
        reportTextArea = new JTextArea(10, 20);

        JButton processReportButton = new JButton("Process Report");
        JButton clearButton = new JButton("Clear");
        JButton saveReportButton = new JButton("Save Report");

        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitMenuItem = new JMenuItem("Exit");
        fileMenu.add(exitMenuItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processReportMenuItem = new JMenuItem("Process Report");
        JMenuItem clearMenuItem = new JMenuItem("Clear");
        JMenuItem saveReportMenuItem = new JMenuItem("Save Report");
        toolsMenu.add(processReportMenuItem);
        toolsMenu.add(clearMenuItem);
        toolsMenu.add(saveReportMenuItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);

        setJMenuBar(menuBar);

        JPanel mainPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        mainPanel.add(new JLabel("Agent Location:"));
        mainPanel.add(locationComboBox);
        mainPanel.add(new JLabel("Agent Name:"));
        mainPanel.add(agentNameField);
        mainPanel.add(new JLabel("Property Price:"));
        mainPanel.add(propertyPriceField);
        mainPanel.add(new JLabel("Commission Percentage:"));
        mainPanel.add(commissionPercentageField);
        mainPanel.add(new JLabel("Report:"));
        mainPanel.add(new JScrollPane(reportTextArea));

        mainPanel.add(processReportButton);
        mainPanel.add(clearButton);
        mainPanel.add(saveReportButton);

        add(mainPanel);

        exitMenuItem.addActionListener(e -> System.exit(0));

        processReportButton.addActionListener(e -> processReport());
        processReportMenuItem.addActionListener(e -> processReport());

        clearButton.addActionListener(e -> clearFields());
        clearMenuItem.addActionListener(e -> clearFields());

        saveReportButton.addActionListener(e -> saveReport());
        saveReportMenuItem.addActionListener(e -> saveReport());
    }

    private void processReport() {
        String location = (String) locationComboBox.getSelectedItem();
        String agentName = agentNameField.getText();
        String propertyPrice = propertyPriceField.getText();
        String commissionPercentage = commissionPercentageField.getText();

        // Validation
        if (estateAgent.validateData(new Data(location, agentName, propertyPrice, commissionPercentage))) {
            double commission = estateAgent.calculateCommission(propertyPrice, commissionPercentage);
            String report = String.format("Location: %s\nAgent Name: %s\nProperty Price: %s\nCommission: R %.2f",
                    location, agentName, propertyPrice, commission);
            reportTextArea.setText(report);
        } else {
            JOptionPane.showMessageDialog(this, "Invalid input. Please check the data and try again.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        locationComboBox.setSelectedIndex(0);
        agentNameField.setText("");
        propertyPriceField.setText("");
        commissionPercentageField.setText("");
        reportTextArea.setText("");
    }

    private void saveReport() {
        try (FileWriter writer = new FileWriter("report.txt")) {
            writer.write(reportTextArea.getText());
            JOptionPane.showMessageDialog(this, "Report saved successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving report.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        SwingUtilities.invokeLater(() -> new EstateAgentGUI());
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EstateAgentGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EstateAgentGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EstateAgentGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EstateAgentGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EstateAgentGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
