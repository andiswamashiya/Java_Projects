/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Agent;

import javafx.scene.chart.PieChart;



/**
 *
 * @author AndiswaBuhle
 */
public abstract class EstateAgent_Property implements iEstateAgent{

    @Override
    public double calculateCommission(String propertyPrice, String agentCommission) {
      double price = Double.parseDouble(propertyPrice);
        double commissionPercentage = Double.parseDouble(agentCommission);
        return price * (commissionPercentage / 100.0); 
    }

    public boolean validateData(Data dataToValidate) {
        return dataToValidate.getLocation() != null && !dataToValidate.getLocation().isEmpty() &&
                dataToValidate.getAgentName() != null && !dataToValidate.getAgentName().isEmpty() &&
                dataToValidate.getPropertyPrice() > 0 &&
                dataToValidate.getCommissionPercentage() > 0;
    
    }
   
}
