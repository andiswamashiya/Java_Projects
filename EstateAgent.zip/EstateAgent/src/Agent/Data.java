/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Agent;

/**
 *
 * @author AndiswaBuhle
 */
public class Data{
 private String location;
    private String agentName;
    private double propertyPrice;
    private double commissionPercentage;

    public Data(String location, String agentName, String propertyPrice, String commissionPercentage) {
        this.location = location;
        this.agentName = agentName;
        this.propertyPrice = Double.parseDouble(propertyPrice);
        this.commissionPercentage = Double.parseDouble(commissionPercentage);
    }

    public String getLocation() {
        return location;
    }

    public String getAgentName() {
        return agentName;
    }

    public double getPropertyPrice() {
        return propertyPrice;
    }

    public double getCommissionPercentage() {
        return commissionPercentage;
    }   
}
