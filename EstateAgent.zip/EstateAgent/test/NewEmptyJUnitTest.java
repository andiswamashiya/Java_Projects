/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import javafx.scene.chart.PieChart.Data;

/**
 *
 * @author AndiswaBuhle
 */
public class NewEmptyJUnitTest {
    
     public void calculateCommission_CalculatedSuccessfully() {
        EstateAgent estateAgent = new EstateAgent();
        double result = estateAgent.calculateCommission("1000000", "2.5");
        assertEquals(25000, result, 0);
    }

    
    public void calculateCommission_CalculatedUnsuccessfully() {
        EstateAgent estateAgent = new EstateAgent();
        double result = estateAgent.calculateCommission("1000000", "abc");
        assertEquals(0, result, 0);
    }

   
    public void validationTest() {
        EstateAgent estateAgent = new EstateAgent();
        boolean result = estateAgent.validateData(new Data("Cape Town", "John Doe", "1000000", "2.5"));
        assertEquals(true, result);
    }

    private void assertEquals(int i, double result, int i0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void assertEquals(boolean b, boolean result) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static class EstateAgent {

        public EstateAgent() {
        }

        private double calculateCommission(String string, String string0) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }
    }

   

