/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Q2;

import java.util.Scanner;

/**
 *
 * @author AndiswaBuhle
 */
abstract class Inspection {

    String hospitalLocation;
    String hospitalName;
    int yearLastInspection;
    String inspectionNeeded;
    
}

class HospitalInspections extends Inspection{
    Scanner in = new Scanner(System.in);
    
    public void hospitalLocation(){
        System.out.println("Enter the Hospital location: ");
        hospitalLocation = in.nextLine();
    }
    public void hospitalName(){
        System.out.println("Enter the Hospital Name: ");
        hospitalName = in.nextLine();
    }
    public void yearLastInspection(){
        System.out.println("Enter Years since last inspection: ");
        yearLastInspection = in.nextInt();
    }
    public String InspectionNeeded(){
        if(yearLastInspection > 3){
           return "YES";
        }
        else{
            return "NO";
        }
        
    }
    public void printInspectionReport(){
        
        System.out.println("\nHOSPITAL INSPECTION REPORT"
                + "\n***************"
                + "\nHOSPITAL LOCATION:       " + hospitalLocation
                + "\nHOSPITAL NAME:           " + hospitalName
                + "\nYEARS SINCE INSPECTION:  " + yearLastInspection
                + "\nINSPECTION NEEDED:       " + InspectionNeeded());
    }

}
    

