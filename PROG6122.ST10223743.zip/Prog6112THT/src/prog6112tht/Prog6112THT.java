/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog6112tht;

/**
 *
 * @author AndiswaBuhle
 */
public class Prog6112THT {

    private static String c1;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    //
        System.out.println("******************************");
        System.out.println("Health Inspection report");
        System.out.println("*******************************");
        String months;
        months ="Jan";
        months = "Feb";
        months = "Mar";
        months = "Avg";
        int a = 4,al=8,a2 =6;
        int b = 5,bl = 4,b2 = 2;
        int c = 4, cl= 2,c2 = 8;
        
        System.out.println("Jan,Feb,Mar,Avg");
        System.out.println("Hospital 1:-->"+ a+al+a2);
        System.out.println("Hospital 2:-->"+b+bl+b2);
        System.out.println("Hospital 3-->"+c+ c1 + c2);
        System.out.println("*******************************");
        System.out.println("Monthly Totals");
        System.out.println("**************************************");
        double aa =6*3;
        double bb =3.67*3;
        double cc = 4.67*3;
        double value = 0;
        System.out.println("Hospital 1:" +aa);
        System.out.println("Hospital 2:" +bb);
        System.out.println("Hospital 3:" +cc);
        System.out.println("****************************************");
        
        Inspection x = new Inspection();
        
        System.out.println("Enter Hospital location");
        System.out.println("Enter Hospital name");
        System.out.println("Enter year since last inspected");
        
         
        
    }
    }
    

  